const express = require("express");
const path = require("path");
const bcrypt = require("bcrypt");
const collection = require("./config");

const app = express();
// Convert data into json format
app.use(express.json());
app.use(express.urlencoded({entended: false}));

// use ejs as view engine
app.set('view engine', 'ejs');

// Static File
app.use(express.static("public"));

app.get("/", (req,res) =>{
    res.render("login");
});

app.get("/signup", (req,res) =>{
    res.render("signup");
});

//Register User
app.post("/signup", async (req,res) =>{
    const data = {
        name: req.body.username,
        password: req.body.password
    }

    // Chech if the user is already registered
    const existingUser = await collection.findOne({name: data.name});

    if(existingUser){
        res.send("User already exists. Please choose a different username.")
    }
    else{
        // hasing the password using bcrypt
        const saltRounds = 10;
        const hashedPasswords = await bcrypt.hash(data.password, saltRounds);
        data.password = hashedPasswords;//replace the hased password

        const userdata = await collection.insertMany(data);
        console.log(userdata);
    }
})

//Login User
app.post("/login", async (req,res) =>{
    try{
        const check = await collection.findOne({name: req.body.username});

        if(!check){
            res.send(`User cannot be found ${pass}`);
        }
        
        const storedHashedPassword = check.password;
        const userInputPassword = req.body.password;
        
        bcrypt.compare(userInputPassword, storedHashedPassword, (err, result) => {
            if (err) {
                // Handle error
                console.error('Error comparing passwords:', err);
                return;
            }
            
            if (result) {
                // Passwords match, authentication successful
                console.log("welcome Home!!")
                res.render("home.ejs");
            } 
            else {
                // Passwords don't match, authentication failed
                console.log('Passwords do not match! Authentication failed.');
                res.send("Wrong password entered");
            }
        });
    }catch{
        res.send("wrong details");
    }
});

const port = 5000;
app.listen(port,()=>{
    console.log(`Server is listening at port: ${port}`);
});